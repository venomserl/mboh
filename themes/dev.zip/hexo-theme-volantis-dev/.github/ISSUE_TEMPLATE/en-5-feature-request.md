---
name: 'Feature Request: add or optimize a certain function'
about: This template is suitable for suggestions and discussions about whether to add new features or make adjustments to existing features.
title: ''
labels: 'feature-request'
assignees: ''

---

<!--

1. Please read the official hexo document to see if it is natively supported.
2. Please search for issues to see if there are already suggestions.
3. If there are none, describe your needs as much as possible below.

-->
